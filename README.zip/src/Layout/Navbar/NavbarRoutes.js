import { Link, Outlet } from 'react-router'
import { useEffect, useState } from 'react';
import '../Navbar/header.scss'

const NavbarRoutes = () => {

    const [isSticky, setIsSticky] = useState(false);


    useEffect(() => {
        const handleScroll = () => {
          if (window.scrollY > 0) {
            setIsSticky(true);
          } else {
            setIsSticky(false);
          }
        };
    
        window.addEventListener('scroll', handleScroll);
    
        return () => {
          window.removeEventListener('scroll', handleScroll);
        };
      }, []);

  return (
    <div>

      <div className={isSticky ? 'header-sticky' : 'main_header'}> 
        <div className='main_container'>
            <div className='logo'>
                <a href='#'><h1>VILLA</h1></a>
            </div>

            <div className='navbar'>
                <ul className='nav'>
                    <li>
                        <Link to='/'>Home</Link>
                    </li>
                </ul>
            </div>
        </div>
      </div>
    <Outlet/>

    </div>
  )
}

export default NavbarRoutes