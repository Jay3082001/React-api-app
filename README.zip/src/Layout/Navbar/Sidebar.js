import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPhone } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router'
import { useDispatch } from 'react-redux';
import { logout } from '../../redux/Authslice';
import { useNavigate } from 'react-router';

const Sidebar = ({ toggleSidebar }) => { 

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleLogout = () => {
      dispatch(logout());
      navigate('/');
      };


  return (
    <div className="sidebar-container">
      <div className="sidebar-backdrop" onClick={toggleSidebar}></div>
      <div className="sidebar-menu">
        <button className="close-sidebar-button" onClick={toggleSidebar}>X</button>
            <ul className='side-nav'>
                    <li>
                        <Link to='/home' onClick={toggleSidebar}>Home</Link> 
                    </li>
                    <li>
                        <Link to='/property' onClick={toggleSidebar}>Properties</Link>
                    </li>
                    <li>
                        <Link to='/details' onClick={toggleSidebar}>Property Details</Link>
                    </li>
                    <li>
                        <Link to='/contact' onClick={toggleSidebar}>Contact Us</Link>
                    </li>
                    <li onClick={handleLogout}>
                        <Link onClick={toggleSidebar}>Log Out</Link>
                    </li>
                    <li>
                        <Link className='nav_link' to='/contact' onClick={toggleSidebar}><i><FontAwesomeIcon icon={faPhone} /></i>Schedule Visit</Link> 
                    </li>
                </ul>
      </div>
    </div>
  );
};

export default Sidebar;