
const Footer = () => {
  return (
    <div className='footer'>
      <h3>Copyright © 2048 Villa Agency Co. Ltd. All rights reserved. Design: Villa Agency Co. Ltd.</h3>
    </div>
  )
}

export default Footer
