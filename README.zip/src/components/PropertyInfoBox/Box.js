import './boxstyle.scss'
// import  UtilizeBoxData  from './UtilizeBoxData'


const Box = ({ data }) => {
  return (
    <div className="properties">
      <div className="properties_main">
        {data.map((property) => (
          <div className="properti_box" key={property.id}>
            <a href="#">
              <img src={property.imgSrc} alt={property.category} />
            </a>
            <span className="catagory">{property.category}</span>
            <h6>{property.price}</h6>
            <h4>{property.address}</h4>
            <ul>
              {Object.entries(property.details).map(([key, value], index) => (
                <li key={index}>
                  {key} : <span>{value}</span>
                </li>
              ))}
            </ul>
            <div className="sch_btn">
              <a href="#">Schedule Plan</a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Box;













// Simple code :---->

// const Box = (props) => {
//     const recoveryarray2 = props.data;
//   return (
//     <div className='properties'>
//       <div className='properties_main'> 
//           {recoveryarray2.map((property) => (
//             <div className='properti_box' key={property.id}>
//               <a href='#'>
//                 <img src={property.imgSrc} alt={property.category} /> 
//               </a>
//               <span className='catagory'>{property.category}</span>  
//               <h6>{property.price}</h6>
//               <h4>{property.address}</h4>
//               <ul>
//                 <li>Bedrooms : <span>{property.bedrooms}</span></li>
//                 <li>Bathrooms : <span>{property.bathrooms}</span></li>
//                 <li>Area : <span>{property.area}</span></li>
//                 <li>Floor : <span>{property.floor}</span></li>
//                 <li>Parking : <span>{property.parking}</span></li>
//               </ul>
//               <div className='sch_btn'>
//                   <a href='#'>Schedule Plan</a>
//               </div>
//             </div>
//           ))}
//         </div>
//     </div>
//   )
// }

// export default Box












