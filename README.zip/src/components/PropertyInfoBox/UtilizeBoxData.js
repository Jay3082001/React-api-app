// import { useEffect, useState } from "react";


// const firstLetterCapital = (str) => {
//    return str.charAt(0).toUpperCase() + str.slice(1);
// }

// const UtilizeBoxData = (property) => {

//     const [details, setDetails] = useState({});

//     useEffect(() => {
//         let details = {};

//         if(property.newDetails){
//             details = property.newDetails;
//         } else {
//             const KeyShow = property.displayinfo || ["bedrooms", "bathrooms", "area", "floor", "parking"];
//             const newLabels = property.newLabels || {};

//             KeyShow.forEach((key) => {
//                 const lable = newLabels[key] || firstLetterCapital(key);
//                 details[lable] = property[key];
//             });
//         }
        
//         setDetails(details);
//     }, [property]);

//   return (details);
// }

// export default UtilizeBoxData;










// const firstLetterCapital = (str) =>
//   str.charAt(0).toUpperCase() + str.slice(1);

// export const formatPropertyDetails = (property) => {
//   let details = {};

//   if (property.newDetails) {
//     details = property.newDetails;
//   } else {
//     const keysToShow = property.displayinfo || ["bedrooms", "bathrooms", "area", "floor", "parking"];
//     const newLabels = property.newLabels || {};

//     keysToShow.forEach((key) => {
//       const label = newLabels[key] || firstLetterCapital(key);
//       details[label] = property[key];
//     });
//   }

//   return details;
// };