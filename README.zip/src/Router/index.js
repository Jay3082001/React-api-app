import { lazy, Suspense } from "react";
import { Route, Routes } from "react-router";
import NavbarRoutes from "../Layout/Navbar/NavbarRoutes";
import Spin from "../components/LoadingSpinner/Spin";

const Home = lazy(() => import("../pages/Home/Home"));

const PageRouter = () => {
  return (
    <Routes>

      {/* Navbar route is set to all pages :- */}
      <Route element={<NavbarRoutes />}>
        
        {/* home page :-  */}
        <Route path="/" element={<Suspense fallback={<Spin size={60} />}><Home /></Suspense>}></Route>

      </Route>

    </Routes>
  );
};

export default PageRouter;























// import { Suspense, lazy } from "react";
// import { Route, Routes } from 'react-router';
// import Contact from '../pages/Contact/Contact'
// import Properties from '../pages/Properties/Properties';
// import Showall from '../components/Properties_components/Showall';
// import Apartment from '../components/Properties_components/Apartment';
// import Villa from '../components/Properties_components/Villa';
// import Penthouse from '../components/Properties_components/Penthouse';
// import Properydetail from '../pages/SingleProperty/Properydetail';
// import DetailsApartment from '../components/Single_property_components/DetailsApartment';
// import DetailsVilla from '../components/Single_property_components/DetailsVilla';
// import DetailsPenthouse from '../components/Single_property_components/DetailsPenthouse';
// import Login from '../pages/Login/IndexLogin';
// import NavbarRoutes from "../components/Navbar_components/NavbarRoutes";
// import ProtectedRoute from "../components/Navbar_components/ProtectedRoute";
// const Home = lazy(() => import('../pages/Home/Home'));

// function MainRouting() {
//   return (
//     <>

//       <Routes>
 
//         <Route path='/' element={<Login/>}/>

//         <Route element={<ProtectedRoute> <NavbarRoutes /></ProtectedRoute>}>
        
//           <Route path='/home' element={
//             <Suspense fallback={<div>Loading Home...</div>}> 
//               <Home /> 
//             </Suspense>} />
//           <Route path='/contact' element={<Contact />} />
//           <Route path='/property' element={<Properties />}>
//               <Route index element={<Showall />} />
//               <Route path='apartment' element={<Apartment />} />
//               <Route path='villa' element={<Villa />} />
//               <Route path='penthouse' element={<Penthouse />} />
//           </Route>
//           <Route path='/details' element={<Properydetail />}>
//               <Route index element={<DetailsApartment />} />
//               <Route path='detailsvilla' element={<DetailsVilla />} />
//               <Route path='detailspenthouse' element={<DetailsPenthouse />} />
//           </Route>
//           <Route path='/home' element={<Home />} >
//               <Route index element={<DetailsApartment />} />
//               <Route path='homedetailsvilla' element={<DetailsVilla />} />
//               <Route path='homedetailspenthouse' element={<DetailsPenthouse />} />
//           </Route>
//         </Route>

//       </Routes>
//     </>
//   );
// }

// export default MainRouting;
