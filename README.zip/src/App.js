import './App.css';
import './Globle.scss'
import PageRouter from './Router/index';

function App() {
  return (
     <>
      <PageRouter/>
    </>
  );
}

export default App;
